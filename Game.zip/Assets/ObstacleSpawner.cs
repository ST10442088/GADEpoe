using UnityEngine;

public class ObstacleSpawner : MonoBehaviour
{

   //This script is meant to instantiate the empty game objects that some obstacles will spawn from
   GameObject emptyGameObjectTrigger;

    [SerializeField] public GameObject emptyGameObjectPrefab;

    int amountOfObstacles = 100;
    int spaceBetweenObstacles = 10;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
       //This was an attempt to spawn all empty game objects in the start of the game, with some debug statements to figure out where the code stops working
    for (int i = 0; i < amountOfObstacles; i++)
    {
           
            print("'Update()' has begun happening");
        Vector3 spawnPoints = new Vector3(-21f, 22f, 96f + i);
     

        Instantiate(emptyGameObjectPrefab, spawnPoints, transform.rotation);

            if(Instantiate(emptyGameObjectPrefab) == true)
            {
                print("The PREFAB HAS SPAWNED");
            }
    }
        print("'Start()' has happened");
        
    }

    // Update is called once per frame
    void Update()
    {
   
    }

    private void OnTriggerEnter(Collider other)
    {
        
       emptyGameObjectPrefab = other.gameObject; 
      
        MaulerMovement maulerPosition = GetComponent<MaulerMovement>();

      emptyGameObjectTrigger = Instantiate(emptyGameObjectPrefab, (new Vector3(maulerPosition.transform.position.x,
          maulerPosition.transform.position.y, maulerPosition.transform.position.z + 50f)), transform.rotation) as GameObject; 
    
    }

}
