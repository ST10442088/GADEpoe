using UnityEngine;

public class MaulerMovement : MonoBehaviour
{
    CharacterController characterController;
    [SerializeField] float maulerMovementSpeed = 100f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
         characterController = GetComponent<CharacterController>();
    }

    // Update is called once per framer
    void Update()
    {
        /* transform.Translate(0, -73f, maulerMovementSpeed * Time.deltaTime);

          if(Input.GetKeyDown(KeyCode.LeftArrow) )
          {   
              gameObject.transform.position = new Vector3(-64f, -73f, transform.position.z);
          }

          if(Input.GetKeyDown(KeyCode.RightArrow) )
          {
              gameObject.transform.position = new Vector3(37f, -73f, -transform.position.z);
          } */

        transform.Translate(0, 0, maulerMovementSpeed * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.LeftArrow) )
        {
            transform.Translate(-50f, 0, maulerMovementSpeed * Time.deltaTime);  
        }

        if(Input.GetKeyDown(KeyCode.RightArrow) )
        {
            transform.Translate(50f, 0, maulerMovementSpeed * Time.deltaTime);
        }
       
    }
}
