using UnityEngine;

public class SphereAppearanceHandler : MonoBehaviour
{
    //The obstacle I wanted to try spawning is a sphere, and this is the class for that
    [SerializeField] GameObject spherePrefab;
    GameObject sphereTrigger;
  
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
          
    }

    // Update is called once per frame
    void Update()
    {
        ObstacleSpawner obstacleSpawn = GetComponent<ObstacleSpawner>();

        if(Instantiate(obstacleSpawn.emptyGameObjectPrefab) == true )
        {
            sphereTrigger = Instantiate(spherePrefab, (new Vector3(spherePrefab.transform.position.x, spherePrefab.transform.position.y,
                spherePrefab.transform.position.z+ 25f)), transform.rotation) as GameObject;
        }


    }

}
